# ColorPicker (Google Chrome Extension)
---
## Follow Below Steps to use this Extension

1. Download .zip  and extract file
[Zip Download](/Color_picker_extension.zip) or Clone repository to your local system.

    ```
    git clone https://github.com/nikhil-x24/Chorme-Extension.git
    ```

2. Open **Google Chrome**
3. Go to **settings**
4. Select **Extensions** tab
5. Turn on **Developer mode**
    ![Screenshot (27)](https://user-images.githubusercontent.com/82399781/210152293-c8168f7b-4699-4785-990a-a989d56834f7.jpg)
6. Click on **Load unpacked**
    ![Screenshot (28)](https://user-images.githubusercontent.com/82399781/210152310-757b0ed6-6bad-4728-bb0c-375a41d45985.jpg)
7. Select **color-picker-chrome-extension** folder
    ![download (1)](https://user-images.githubusercontent.com/82399781/210152496-75f7e665-040e-4d27-a2cf-00f27392c504.png)
8. Enable This Extension (if Disabled).
9. Now open any **tab other than google setting/home page**.
10. Now click on **Extension icon** and select **color picker**
11. Now press on **pick color**, and move cursor and *click anywhere* on **browser or in desktop** anywhere to pick color.

12. You will get HexCode of the choosed color.
13. paste anywhere to use the HexCode (already copied to clipboard).

14. I Hope this will help you to **get specific Color HexCode** from anywhere you want.

15. Always ready for any kind of **Guidance/support and Help.**


**Thanks for Reading and Using this**.

---
---
**Note:** Learned and implemented with the help of youtube and Reading Docs. 
